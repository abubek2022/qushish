import os
from colorama import init, Fore
from time import sleep
import csv
import time
import random
import os
import sys
init()

n = Fore.RESET
lg = Fore.BLUE
r = Fore.RED
w = Fore.WHITE
cy = Fore.CYAN
ye = Fore.YELLOW
gr = Fore.GREEN
rs = Fore.RESET
colors = [lg, r, w, cy, ye, gr]

try:
    import requests
except ImportError:
    print(f'{lg}[i] Installing module - requests...{n}')
    os.system('pip install requests')

def banner():

	b = [

		"|\  /|       __  __   __| '  __   __",
		"| \/ | |  | |   |  | |  | | |  | |  |",
		"|    | |__| |   |__| |__| | |__| |  |",
		"                         _/"
		]

	c = [
		"     ___  ___   ___        ___ ___        ",
		"|  |   / |   | |    | / | |     |   /\   |\  |",
		"|  |  /  |--<  |--  |<  |  --   |  /__\  | \ |",
		"|__| /__ |___| |___ | \ | ___|  | /    \ |  \|"
		]

	d = [
		"     ___  ___   ___    ",
		"|  |   / |   | |    | /",
		"|  |  /  |--<  |--  |< ",
		"|__| /__ |___| |___ | \\"
		]
	u = c
	x = 0
	for char in u:
		if u == b:
			flag_color = [lg, w, gr, gr]
		else:
			flag_color = [lg, lg, w, gr, gr]
		# random.shuffle(colors)
		if x >= 4:
			x = 0
		print(f"{flag_color[x]}{char}{rs}")
		x += 1
	print('\n')

	print(f'{lg}   Version: {w}1.0{lg} | Editor: {w}ALPHA_UZS{rs}\n')

def clr():
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
while True:
    clr()
    banner()
    print(ye+'Choose an Option:'+n)
    print(cy+'            [1] Modulni yuklash'+n)
    print(cy+'            [2] Chqish'+n)
    a = int(input('\n Enter your choice: '))
    if a == 1:
    
       print("[+] Installing requierments ...")
       os.system('pip install pyrogram')
       os.system('pip install colorama')
       os.system('pip install pyfiglet')
       os.system('pip install lolpython')
       os.system('pip install cPython')
       os.system('pip install TgCrypto')
       

       print(f"{gr}[+] Vazifa Bajarildi !")
       print(f"{gr}[+] Chiqib Free.py faylga kiring !")
       input(f'{r}\n Menyuga qaytish uchun ENTERNI bosing...')
       
    if a == 2:
        clr()
        banner()
        exit()